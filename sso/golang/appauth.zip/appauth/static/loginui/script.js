document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault(); // Mencegah refresh halaman

    // Mengambil data dari input
    // const username = document.getElementById('username').value;
    const email = document.getElementById('email').value
    const password = document.getElementById('password').value;

    // Membungkus data dalam objek JSON
    const payload = {
        // username: username,
        email: email,
        password: password
    };

    try {
        // Mengirim data ke /loginui
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(payload)
        });

        // Menampilkan hasil (karena /loginui mungkin belum ada, ini akan error 404)
        // console.log(await response.json())
        const responsejson = await response.json()
        // console.log(responsejson.errors.message)
        if (response.ok) {
            document.getElementById('responseMessage').innerText = "Data Berhasil Terkirim!";
        } else if (response.redirected) {
            console.log("redirect")
            window.location.href = response.url;
            return;
        } else {
            // document.getElementById('responseMessage').innerText = "Error: " + response.statusText;
            document.getElementById('responseMessage').innerText = responsejson.errors.message
        }
    } catch (error) {
        document.getElementById('responseMessage').innerText = "Gagal menghubungi server.";
        console.error("Detail Error:", error);
    }
});